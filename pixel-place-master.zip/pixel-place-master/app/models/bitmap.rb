class Bitmap < ApplicationRecord
end
