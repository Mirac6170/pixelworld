class PlaceController < ApplicationController
  def index
  end
end
