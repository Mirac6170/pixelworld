module PlaceHelper
end
